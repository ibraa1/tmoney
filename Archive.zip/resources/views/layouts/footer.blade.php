<footer class="app-footer">
    <ul class="list-inline">
        {{-- <li class="list-inline-item">
            <a class="text-muted" href="#">Support</a>
        </li>
        <li class="list-inline-item">
            <a class="text-muted" href="#">Help Center</a>
        </li>
        <li class="list-inline-item">
            <a class="text-muted" href="#">Privacy</a>
        </li>
        <li class="list-inline-item">
            <a class="text-muted" href="#">Terms of Service</a>
        </li> --}}
    </ul>
    <div class="copyright"> Copyright © 2023. All right reserved. </div>
</footer><!-- /.app-footer -->
